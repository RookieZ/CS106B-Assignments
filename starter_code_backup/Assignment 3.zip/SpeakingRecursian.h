#pragma once

#include "vector.h"
#include <string>

Vector<std::string> allRecursianWords(int numSyllables);
