#include "MyOptionalHashTable.h"
using namespace std;

MyOptionalHashTable::MyOptionalHashTable(HashFunction<string> hashFn) {
    /* OPTIONAL: Delete this comment and the next line, then implement this function. */
    (void) hashFn;
}

MyOptionalHashTable::~MyOptionalHashTable() {
    /* OPTIONAL: Delete this comment, then implement this function. */
}

int MyOptionalHashTable::size() const {
    /* OPTIONAL: Delete this comment and the next lines, then implement this function. */
    return -1;
}

bool MyOptionalHashTable::isEmpty() const {
    /* OPTIONAL: Delete this comment and the next lines, then implement this function. */
    return false;
}

bool MyOptionalHashTable::insert(const string& elem) {
    /* OPTIONAL: Delete this comment and the next lines, then implement this function. */
    (void) elem;
    return false;
}

bool MyOptionalHashTable::contains(const string& elem) const {
    /* OPTIONAL: Delete this comment and the next lines, then implement this function. */
    (void) elem;
    return false;
}

bool MyOptionalHashTable::remove(const string& elem) {
    /* OPTIONAL: Delete this comment and the next lines, then implement this function. */
    (void) elem;
    return false;
}

/* OPTIONAL: Add custom test cases below this point. */
#include "GUI/SimpleTest.h"
